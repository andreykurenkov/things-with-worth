package info.bliki.wiki.tags;

public class BrTag extends HTMLEndTag {
	public BrTag() {
		super("br");
	}

}