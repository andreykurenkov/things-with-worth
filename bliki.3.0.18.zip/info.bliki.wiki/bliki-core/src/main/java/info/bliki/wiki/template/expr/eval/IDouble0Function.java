package info.bliki.wiki.template.expr.eval;

public interface IDouble0Function {
	public double evaluate();
}
